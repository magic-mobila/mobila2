<?php

wa('webasyst');
class photosFrontendRegionsController extends webasystBackendRegionsController
{

}