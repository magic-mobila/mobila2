<?php

class photosPageParamsModel extends waPageParamsModel
{
    protected $table = 'photos_page_params';
}