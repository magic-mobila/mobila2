<?php

class photosPlugin extends waPlugin
{
}