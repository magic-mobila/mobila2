<?php

class photosMyNavAction extends waMyNavAction
{
}