<?php

class photosPageModel extends waPageModel
{
    protected $app_id = 'photos';
    protected $table = 'photos_page';
}