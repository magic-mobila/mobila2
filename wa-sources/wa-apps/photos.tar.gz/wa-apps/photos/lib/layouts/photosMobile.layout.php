<?php

class photosMobileLayout extends waLayout
{

}