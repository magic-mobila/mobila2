<?php

return array(
    'photos_per_page' => 50,
    'sizes' => array(),
    'max_size' => 1500,
    'sharpen' => 1,
    'thumbs_on_demand' => 1,
    'save_original' => 1,
    'expire_interval' => 180,
    'save_quality' => 90,
    'enable_2x' => 1,
    'save_quality_2x' => 70,
);

